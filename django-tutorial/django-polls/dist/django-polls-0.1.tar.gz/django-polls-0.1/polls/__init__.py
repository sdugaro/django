
default_app_config = 'polls.apps.PollsConfig'
